package com.example.hw4q1

import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.tooling.preview.Preview
import com.example.hw4q1.ui.theme.HW4Q1Theme

data class Product(val name: String, val price: String, val description: String)

@Composable
fun MultiPaneShoppingApp(modifier: Modifier = Modifier) {
    val products = listOf(
        Product("Product A", "$100", "This is a great product A."),
        Product("Product B", "$150", "This is product B with more features."),
        Product("Product C", "$200", "Premium product C.")
    )
    var selectedProduct by remember { mutableStateOf<Product?>(null) }
    val configuration = LocalConfiguration.current

    if (configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
        // Landscape: display both panes side by side.
        Row(modifier = modifier.fillMaxSize()) {
            ProductList(
                products = products,
                onProductClick = { selectedProduct = it },
                modifier = Modifier.weight(1f)
            )
            ProductDetails(
                product = selectedProduct,
                onBack = { selectedProduct = null },
                modifier = Modifier.weight(1f)
            )
        }
    } else {
        // Portrait: show one pane at a time.
        if (selectedProduct == null) {
            ProductList(
                products = products,
                onProductClick = { selectedProduct = it },
                modifier = modifier.fillMaxSize()
            )
        } else {
            ProductDetails(
                product = selectedProduct,
                onBack = { selectedProduct = null },
                modifier = modifier.fillMaxSize()
            )
        }
    }
}

@Composable
fun ProductList(
    products: List<Product>,
    onProductClick: (Product) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(modifier = modifier.fillMaxSize()) {
        items(products) { product ->
            Text(
                text = product.name,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onProductClick(product) }
                    .padding(16.dp)
            )
        }
    }
}

@Composable
fun ProductDetails(
    product: Product?,
    onBack: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    if (product == null) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Select a product to view details.")
        }
    } else {
        Column(modifier = modifier.padding(16.dp)) {
            if (onBack != null) {
                Button(onClick = onBack) { Text("Back") }
                Spacer(modifier = Modifier.height(8.dp))
            }
            Text(product.name, style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(4.dp))
            Text(product.price, style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(4.dp))
            Text(product.description, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            HW4Q1Theme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    MultiPaneShoppingApp(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    HW4Q1Theme {
        MultiPaneShoppingApp()
    }
}
