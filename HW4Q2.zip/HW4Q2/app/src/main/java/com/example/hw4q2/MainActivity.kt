package com.example.hw4q2


import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

/**
 * Simple word + hint data
 */
data class WordData(val word: String, val hint: String)

/**
 * A small pool of words for demonstration
 */
val wordPool = listOf(
    WordData("FOOD", "Something you eat"),
    WordData("APPLE", "A type of fruit"),
    WordData("KOTLIN", "A programming language"),
    WordData("HANGMAN", "The name of the game"),
)

/**
 * Our Hangman game state holder, with a Saver for rotation.
 */
class HangmanGameState(private val context: Context) {
    var currentWord by mutableStateOf("")
    var currentHint by mutableStateOf("")
    var guessedLetters by mutableStateOf(setOf<Char>())
    var disabledLetters by mutableStateOf(setOf<Char>())
    var incorrectGuesses by mutableStateOf(0)
    var hintPressCount by mutableStateOf(0)
    var displayedHint by mutableStateOf("") // what to display under "HINT: "

    val maxGuesses = 6 // 6 incorrect guesses -> user loses

    companion object {
        fun saver(context: Context): Saver<HangmanGameState, List<Any>> = Saver(
            save = { state ->
                listOf(
                    state.currentWord,
                    state.currentHint,
                    state.guessedLetters.joinToString(""),
                    state.disabledLetters.joinToString(""),
                    state.incorrectGuesses,
                    state.hintPressCount,
                    state.displayedHint
                )
            },
            restore = { restoredList ->
                HangmanGameState(context).apply {
                    currentWord = restoredList[0] as String
                    currentHint = restoredList[1] as String
                    guessedLetters = (restoredList[2] as String).toSet()
                    disabledLetters = (restoredList[3] as String).toSet()
                    incorrectGuesses = restoredList[4] as Int
                    hintPressCount = restoredList[5] as Int
                    displayedHint = restoredList[6] as String
                }
            }
        )
    }

    init {
        newGame()
    }

    /**
     * Start a new random word game
     */
    fun newGame() {
        val randomData = wordPool.random()
        currentWord = randomData.word.uppercase()
        currentHint = randomData.hint
        guessedLetters = emptySet()
        disabledLetters = emptySet()
        incorrectGuesses = 0
        hintPressCount = 0
        displayedHint = ""
    }

    /**
     * The user guesses a letter
     */
    fun guessLetter(letter: Char) {
        if (letter in guessedLetters || letter in disabledLetters) return

        val correct = letter in currentWord
        if (!correct) {
            incorrectGuesses++
            Toast.makeText(context, "Wrong!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Correct!", Toast.LENGTH_SHORT).show()
        }

        guessedLetters = guessedLetters + letter
        disabledLetters = disabledLetters + letter
    }

    /**
     * Check if using the hint now would cause immediate loss
     * (only relevant for the 2nd or 3rd hint usage, which cost a turn)
     */
    fun canUseHint(): Boolean {
        val nextMistakeWouldLose = (incorrectGuesses == maxGuesses - 1)
        val aboutToCostTurn = (hintPressCount >= 1) // 2nd or 3rd press costs a turn
        return !(nextMistakeWouldLose && aboutToCostTurn)
    }

    /**
     * Multi-step hint logic:
     * 1st press -> show a toast with the hint, store it for display
     * 2nd press -> disable half of the remaining non-word letters, cost a turn
     * 3rd press -> reveal vowels (and disable them), cost a turn
     */
    fun useHint() {
        if (!canUseHint()) {
            Toast.makeText(context, "Hint not available", Toast.LENGTH_SHORT).show()
            return
        }
        hintPressCount++
        when (hintPressCount) {
            1 -> {
                displayedHint = currentHint
                Toast.makeText(context, "Hint: $currentHint", Toast.LENGTH_LONG).show()
            }
            2 -> {
                disableHalfOfNonWordLetters()
                incorrectGuesses++ // cost a turn
            }
            3 -> {
                revealAllVowels()
                incorrectGuesses++ // cost a turn
            }
        }
    }

    private fun disableHalfOfNonWordLetters() {
        val notInWord = ('A'..'Z').toSet() - currentWord.toSet() - disabledLetters
        val halfSize = notInWord.size / 2
        val toDisable = notInWord.shuffled().take(halfSize)
        disabledLetters = disabledLetters + toDisable
    }

    private fun revealAllVowels() {
        val vowels = setOf('A', 'E', 'I', 'O', 'U')
        guessedLetters = guessedLetters + (vowels intersect currentWord.toSet())
        disabledLetters = disabledLetters + vowels
    }

    fun isGameOver(): Boolean = (incorrectGuesses >= maxGuesses) || isWordComplete()
    fun isWordComplete(): Boolean = currentWord.all { it in guessedLetters }
}

/**
 * A convenience @Composable to remember our HangmanGameState across rotations
 */
@Composable
fun rememberHangmanGameState(): HangmanGameState {
    val context = LocalContext.current
    return rememberSaveable(
        saver = HangmanGameState.saver(context)
    ) {
        HangmanGameState(context)
    }
}

/**
 * The top-level screen: decides layout based on orientation.
 */
@Composable
fun HangmanGameScreen() {
    val configuration = LocalConfiguration.current
    val orientation = configuration.orientation
    val gameState = rememberHangmanGameState()

    if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
        // EXACT layout matching the first screenshot:
        // Left side: 2 panels stacked (Panel1 + Panel2)
        // Right side: main game (Panel3)
        Row(Modifier.fillMaxSize()) {
            // Left side: Column with Panel1 (choose letter) + Panel2 (hint)
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                Panel1ChooseLetter(gameState, Modifier.weight(0.75f))
                Panel2Hint(gameState, Modifier.weight(0.25f))
            }
            // Right side: main game panel
            Panel3MainGame(gameState, Modifier.weight(1f))
        }
    } else {
        // Portrait: simpler vertical layout with NO hint button
        // The second screenshot is basically:
        // Hangman figure at top, partial word, then "CHOOSE A LETTER" label + letter buttons
        Column(Modifier.fillMaxSize()) {
            Panel3MainGame(gameState, Modifier.weight(0.6f))
            Panel1ChooseLetter(gameState, Modifier.weight(0.4f), showTitle = true)
        }
    }
}

/**
 * Panel 1: “CHOOSE A LETTER” + the grid of letter buttons
 */
@Composable
fun Panel1ChooseLetter(
    gameState: HangmanGameState,
    modifier: Modifier = Modifier,
    showTitle: Boolean = false
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp)
    ) {
        Text(
            text = "CHOOSE A LETTER",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
        )
        Spacer(Modifier.height(8.dp))

        // A simple A-Z grid
        val letters = ('A'..'Z').toList()
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(letters.chunked(6)) { rowLetters ->
                Row {
                    for (letter in rowLetters) {
                        val enabled = letter !in gameState.disabledLetters
                        Button(
                            onClick = { gameState.guessLetter(letter) },
                            enabled = enabled,
                            modifier = Modifier
                                .padding(4.dp)
                                .weight(1f)
                        ) {
                            Text(letter.toString())
                        }
                    }
                }
            }
        }
    }
}

/**
 * Panel 2: The Hint button & displayed hint text
 */
@Composable
fun Panel2Hint(
    gameState: HangmanGameState,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        horizontalAlignment = Alignment.Start
    ) {
        // A button that triggers multi-step hints
        Button(
            onClick = { gameState.useHint() },
            enabled = !gameState.isGameOver(),
        ) {
            Text("Hint")
        }
        Spacer(Modifier.height(16.dp))

        // The instructions show "HINT: FOOD" at the bottom
        // We'll display the currently revealed hint (if any).
        Text(
            text = "HINT: ${gameState.displayedHint}",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(top = 8.dp)
        )
    }
}

/**
 * Panel 3: Main Game – The hangman figure, partial word, and “New Game” button
 */
@Composable
fun Panel3MainGame(
    gameState: HangmanGameState,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // The Hangman figure (gallows + body parts)
        HangmanFigure(gameState.incorrectGuesses, Modifier.weight(1f))

        // Show partial word with guessed letters
        val displayedWord = gameState.currentWord.map {
            if (it in gameState.guessedLetters) it else '_'
        }.joinToString(" ")
        Text(
            text = displayedWord,
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(top = 8.dp)
        )

        // If game over, show message
        if (gameState.isGameOver()) {
            Spacer(Modifier.height(8.dp))
            if (gameState.isWordComplete()) {
                Text("You WIN!", color = MaterialTheme.colorScheme.primary)
            } else {
                Text("You LOSE! The word was: ${gameState.currentWord}")
            }
        }

        Spacer(Modifier.height(16.dp))
        // New Game button
        Button(
            onClick = { gameState.newGame() }
        ) {
            Text("New Game")
        }
    }
}

/**
 * A simple Canvas-based Hangman figure with 6 possible mistakes:
 * 1: Head, 2: Body, 3: One arm, 4: Other arm, 5: One leg, 6: Other leg
 */
@Composable
fun HangmanFigure(
    incorrectGuesses: Int,
    modifier: Modifier = Modifier
) {
    // We draw the gallows plus up to 6 body parts
    Canvas(modifier = modifier.fillMaxWidth()) {
        // Draw gallows
        // base line
        drawLine(
            color = Color.Black,
            start = Offset(x = 0f, y = size.height - 10),
            end = Offset(x = size.width * 0.6f, y = size.height - 10),
            strokeWidth = 8f
        )
        // upright
        drawLine(
            color = Color.Black,
            start = Offset(x = size.width * 0.1f, y = size.height - 10),
            end = Offset(x = size.width * 0.1f, y = 10f),
            strokeWidth = 8f
        )
        // top bar
        drawLine(
            color = Color.Black,
            start = Offset(x = size.width * 0.1f, y = 10f),
            end = Offset(x = size.width * 0.5f, y = 10f),
            strokeWidth = 8f
        )
        // rope
        drawLine(
            color = Color.Black,
            start = Offset(x = size.width * 0.5f, y = 10f),
            end = Offset(x = size.width * 0.5f, y = 60f),
            strokeWidth = 4f
        )

        // Now draw body parts based on mistakes
        // 1) Head
        if (incorrectGuesses >= 1) {
            drawCircle(
                color = Color.Black,
                center = Offset(x = size.width * 0.5f, y = 80f),
                radius = 20f,
                style = Stroke(width = 4f)
            )
        }
        // 2) Body
        if (incorrectGuesses >= 2) {
            drawLine(
                color = Color.Black,
                start = Offset(x = size.width * 0.5f, y = 100f),
                end = Offset(x = size.width * 0.5f, y = 160f),
                strokeWidth = 4f
            )
        }
        // 3) Left arm
        if (incorrectGuesses >= 3) {
            drawLine(
                color = Color.Black,
                start = Offset(x = size.width * 0.5f, y = 110f),
                end = Offset(x = size.width * 0.4f, y = 140f),
                strokeWidth = 4f
            )
        }
        // 4) Right arm
        if (incorrectGuesses >= 4) {
            drawLine(
                color = Color.Black,
                start = Offset(x = size.width * 0.5f, y = 110f),
                end = Offset(x = size.width * 0.6f, y = 140f),
                strokeWidth = 4f
            )
        }
        // 5) Left leg
        if (incorrectGuesses >= 5) {
            drawLine(
                color = Color.Black,
                start = Offset(x = size.width * 0.5f, y = 160f),
                end = Offset(x = size.width * 0.45f, y = 200f),
                strokeWidth = 4f
            )
        }
        // 6) Right leg
        if (incorrectGuesses >= 6) {
            drawLine(
                color = Color.Black,
                start = Offset(x = size.width * 0.5f, y = 160f),
                end = Offset(x = size.width * 0.55f, y = 200f),
                strokeWidth = 4f
            )
        }
    }
}

/**
 * MainActivity sets the HangmanGameScreen
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme {
                HangmanGameScreen()
            }
        }
    }
}

/**
 * Previews
 */
@Preview(showBackground = true, widthDp = 800, heightDp = 400)
@Composable
fun PreviewLandscape() {
    MaterialTheme {
        HangmanGameScreen()
    }
}

@Preview(showBackground = true, widthDp = 400, heightDp = 800)
@Composable
fun PreviewPortrait() {
    MaterialTheme {
        HangmanGameScreen()
    }
}
